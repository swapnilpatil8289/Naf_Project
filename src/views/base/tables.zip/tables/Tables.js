import React,{Component} from 'react';
import ReactTable from "react-table";  
import DatePicker from 'react-datepicker';
import * as moment from 'moment';
import {
  CBadge,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CDataTable,
  CRow
} from '@coreui/react'
import "react-datepicker/dist/react-datepicker.css";
import 'bootstrap/dist/css/bootstrap.min.css';


//import usersData from '../../users/UsersData'

class Tables extends Component {
   constructor(props){
     super(props);
     this.state ={
       posts:[],
       startDate: new Date(),
       endDate: new Date()

     };
     alert(this.state.startDate);
     alert(this.state.endDate);
     this.handleChange = this.handleChange.bind(this);
     this.handleChange1 = this.handleChange1.bind(this);
     this.onFormSubmit = this.onFormSubmit.bind(this);
   }
   handleChange(date) {
    this.setState({
      startDate: date
    })

  }
  handleChange1(date) {
    this.setState({
      endDate: date
    })
 
  }
  onFormSubmit(e) {
    e.preventDefault();
    alert("OK....");
   // alert(this.state.posts);
    //console.log(this.state.startDate)
   // console.log(this.state.endDate)
   then(response=> response.json()).then(posts => {
    this.setState({posts:posts})
  })
  }

 
   componentDidMount(){
     //const url="http://13.235.146.159:8084/api/naf_weather/findall";
    const data = {startDate:this.state.startDate, end_date:this.state.endDate};
   // const startDate1 = this.state.startDate.toLocaleDateString().slice(0, 10) 
   // .split('/').reverse().join('-');
   // const endDate1 = this.state.startDate+1;
   // const endDate2  = endDate1.toLocaleDateString().slice(0, 10).split('/').reverse().join('-');

    // const url=`http://13.235.146.159:8084/api/naf_weather/find_val/?start_date={encodeURIComponent(data.startDate)&endDate={encodeURIComponent(data.endDate)}`;
    
    alert(`http://13.235.146.159:8084/api/naf_weather/find_val/${this.state.startDate.toLocaleDateString().slice(0, 10) 
    .split('/').reverse().join('-')}/${this.state.endDate.toLocaleDateString().slice(0, 10) 
    .split('/').reverse().join('-')}`);
    fetch(`http://13.235.146.159:8084/api/naf_weather/find_val/$this.state.startDate.toLocaleDateString().slice(0, 10) 
    .split('/').reverse().join('-')}/${this.state.endDate.toLocaleDateString().slice(0, 10) 
      .split('/').reverse().join('-')}`,{
       method:"GET"
     })

  

   }
   handleClick = () => {
    console.log('this is:', this);
  }
  
   render(){
   // const fields = ['date','time', 'temperature','pressure','humidity','windspeed','rain','solarradiation','winddirection','status','date_time','battery','solar','noofrecords','logging_time']

    const fields = ['date','time', 'temperature','pressure','humidity','windspeed','rain','solarradiation','winddirection']

  
    return (
      <form onSubmit={ this.onFormSubmit }>
        <div className="form-group">
          <DatePicker
              selected={ this.state.startDate }
              onChange={ this.handleChange }
              name="startDate"
              dateFormat="yyyy-MM-dd"
          /><></>
                   <DatePicker
              selected={ this.state.endDate }
              onChange={ this.handleChange1 }
              name="endDate"
              dateFormat="yyyy-MM-dd"
          /><></>
          <button className="btn btn-primary">Show Date</button>
     
      <>
        <CRow>
          <CCol xs="25" lg="12">
            <CCard>
              <CCardHeader>
                Weather Data
              </CCardHeader>
              <CCardBody>
              <CDataTable
                items={this.state.posts}
                fields={fields}
                itemsPerPage={8}
                pagination
  
              />
              </CCardBody>
            </CCard>
          </CCol>
  
          
        </CRow>
      </>
        </div>
      </form>

    )
   }

}



//export default Tables




//const Tables1 = () => {
  
//}

export default Tables
